package com.dicoding.picodiploma.githubsubmission

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.githubsubmission.databinding.ItemRowUserBinding
import com.dicoding.picodiploma.githubsubmission.databinding.ItemUserBinding

class ListUserAdapter(private val listUser: ArrayList<Users>) : RecyclerView.Adapter<ListUserAdapter.ViewHolder>() {



    class ViewHolder(private var listUserBinding: ItemRowUserBinding) :
        RecyclerView.ViewHolder(listUserBinding.root) {
        val tvName: TextView = listUserBinding.tvItemName
        val ivAvatar: ImageView = listUserBinding.imgItemAvatar
    }
    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        val binding = ItemRowUserBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvName.text = listUser[position].username
        Glide.with(holder.itemView.context)
            .load(listUser[position].avatar)
            .circleCrop()
            .into(holder.ivAvatar)

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, UserDetails::class.java)
            intent.putExtra(UserDetails.USERNAME, listUser[position].username)
            intent.putExtra(UserDetails.ID, listUser[position].id)
            intent.putExtra(UserDetails.AVATAR, listUser[position].avatar)
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount() = listUser.size

    private var onItemClickCallback: OnItemClickCallback? = null
    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }
    interface OnItemClickCallback {
        fun onItemClicked(data: Users)
    }

}

