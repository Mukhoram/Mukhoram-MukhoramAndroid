package com.dicoding.picodiploma.githubsubmission

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Users(
    val username: String? = null,
    val id: Int,
    val avatar: String? = null,
    val name: String? = null,
    val location: String? = null,
    val repository: String? = null,
    val company: String? = null,
    val followers: String? = null,
    val following: String? = null,
) :Parcelable
