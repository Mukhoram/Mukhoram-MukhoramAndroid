package com.dicoding.picodiploma.githubsubmission

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.githubsubmission.databinding.ItemUserBinding

class FollowAdapter (private val listFollowers: ArrayList<Users>) : RecyclerView.Adapter<FollowAdapter.ViewHolder>() {

    class ViewHolder(var binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ViewHolder(binding)}


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
       val(txt_username,img_avatar)=listFollowers[position]
        holder.binding.txtUsername.text = listFollowers[position].username

        Glide.with(holder.itemView.context)
            .load(listFollowers[position].avatar)
            .circleCrop()
            .into(holder.binding.imgAvatar)

    }

    override fun getItemCount() = listFollowers.size

}