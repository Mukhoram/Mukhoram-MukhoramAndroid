package com.dicoding.picodiploma.githubsubmission

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.githubsubmission.databinding.ActivityUserDetailsBinding
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Callback
import retrofit2.Response

class UserDetails : AppCompatActivity() {
    companion object {
        const val TAG = "UserDetailsActivity"
        const val USERNAME = "username"
        const val ID = "id"
        const val AVATAR = "avatar"

        @StringRes
        private val TAB_TITLES = intArrayOf(R.string.tab_text_1, R.string.tab_text_2)
    }

    private lateinit var UserDetailsBinding: ActivityUserDetailsBinding
    private lateinit var detailViewModel: UserDetailsViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        UserDetailsBinding = ActivityUserDetailsBinding.inflate(layoutInflater)
        setContentView(UserDetailsBinding.root)

        detailViewModel = ViewModelProvider(this).get(UserDetailsViewModel::class.java)

        val username = intent.getStringExtra(USERNAME)
        val id = intent.getIntExtra(ID, 0)
        val avatar = intent.getStringExtra(AVATAR)
        displayUserDetail(username.toString())

        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        sectionsPagerAdapter.username = username.toString()

        UserDetailsBinding.viewPager.adapter = sectionsPagerAdapter
        TabLayoutMediator(UserDetailsBinding.tabs, UserDetailsBinding.viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        supportActionBar?.elevation = 0f

        var isChecked = false
        CoroutineScope(Dispatchers.IO).launch{
            val count = detailViewModel.checkUser(id)
            withContext(Dispatchers.Main){
                if (count != null) {
                    if (count>0){
                        UserDetailsBinding.favButton.isChecked = true
                        isChecked = true
                    } else {
                        UserDetailsBinding.favButton.isChecked = false
                        isChecked = false
                    }
                }
            }
        }
        UserDetailsBinding.favButton.setOnClickListener{
            isChecked = !isChecked
            if (isChecked){
                if (username != null && avatar != null) {
                    detailViewModel.addToFavorite(username, id, avatar)
                }
            }
            else{
                detailViewModel.removeFromFavorite(id)
            }
            UserDetailsBinding.favButton.isChecked = isChecked
        }
    }
    private fun displayUserDetail(username: String) {
        showLoading(true)

        val client = ApiConfig.getApiService().getUserDetail(username)
        client.enqueue(object : Callback<UserDetailsResponse> {
            override fun onResponse(
                call: retrofit2.Call<UserDetailsResponse>,
                response: Response<UserDetailsResponse>
            ) {
                showLoading(false)
                if(response.isSuccessful) {
                    val responseBody = response.body()
                    if(responseBody != null) {
                        setUsersData(responseBody)
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: retrofit2.Call<UserDetailsResponse>, t: Throwable) {
                showLoading(false)
                Log.e(TAG, "onFailure: ${t.message}")
            }

        })
    }
    private fun setUsersData(items: UserDetailsResponse) {
        Glide.with(this)
            .load(items.avatarUrl)
            .circleCrop()
            .into(UserDetailsBinding.ivDetAvatar)

        val textDetailName = items.name
        val textDetailUsername = items.login
        val textDetailCompany = "Company : ${items.company}"
        val textDetailLocation = "Location : ${items.location}"
        val textDetailRepos = "Repositories : ${items.publicRepos}"

        UserDetailsBinding.tvDetName.text = textDetailName
        UserDetailsBinding.tvDetUsername.text = textDetailUsername
        UserDetailsBinding.tvDetCompany.text = textDetailCompany
        UserDetailsBinding.tvDetLocation.text = textDetailLocation
        UserDetailsBinding.tvDetRepository.text = textDetailRepos
    }

    private fun showLoading(isLoading: Boolean) {
        if(isLoading) {
            UserDetailsBinding.progressBar.visibility = View.VISIBLE
        } else {
            UserDetailsBinding.progressBar.visibility = View.GONE
        }
    }
}