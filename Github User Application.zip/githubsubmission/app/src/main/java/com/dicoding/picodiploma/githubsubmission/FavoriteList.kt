package com.dicoding.picodiploma.githubsubmission

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.githubsubmission.databinding.ActivityFavoriteListBinding

class FavoriteList : AppCompatActivity() {


    private lateinit var binding: ActivityFavoriteListBinding
    private lateinit var adapter: ListUserAdapter
    private lateinit var viewModel: FavoriteListViewModel
    val list = ArrayList<Users>()

    private fun setList(users: ArrayList<Users>) {
        list.clear()
        list.addAll(users)
        adapter.notifyDataSetChanged()
    }
    private fun mapList(users: List<FavoriteUser>): ArrayList<Users> {
        val listUser = ArrayList<Users>()
        for(user in users){
            val userMapped = Users(
                username = user.login,
                id = user.id,
                avatar = user.avatar
            )
            listUser.add(userMapped)
        }
        return listUser
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteListBinding.inflate(layoutInflater)
        setContentView(binding.root)



        adapter = ListUserAdapter(list)

        viewModel = ViewModelProvider(this)[FavoriteListViewModel::class.java]

        adapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback {
            override fun onItemClicked(data:Users){
                Intent(this@FavoriteList, UserDetails::class.java).also{
                    it.putExtra(UserDetails.USERNAME, data.username)
                    it.putExtra(UserDetails.ID,data.id)
                    it.putExtra(UserDetails.AVATAR, data.avatar)
                    startActivity(it)
                }
            }

        })


        binding.apply {
            rvFav.setHasFixedSize(true)
            rvFav.layoutManager = LinearLayoutManager(this@FavoriteList)
            rvFav.adapter = adapter
        }
        viewModel.getFavoriteUser()?.observe(this) {
            if (it != null) {
                setList(mapList(it))

            }
        }
    }


}