package com.dicoding.picodiploma.githubsubmission

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getUsers(
        @Query("q") q: String,
        @Query("per_page") per_page: Int
    ): Call<UserResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getUserDetail(
        @Path("username") username: String
    ): Call<UserDetailsResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getUserFollowers(
        @Path("username") username: String
    ): Call<List<FollowersResponse>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getUserFollowing(
        @Path("username") username: String
    ): Call<List<FollowingResponse>>
}