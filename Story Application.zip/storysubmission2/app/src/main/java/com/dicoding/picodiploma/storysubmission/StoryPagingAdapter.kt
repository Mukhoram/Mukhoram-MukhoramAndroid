package com.dicoding.picodiploma.storysubmission

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.core.util.Pair
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.storysubmission.databinding.ItemRowUserBinding


class StoryPagingAdapter :
    PagingDataAdapter<PagingStoryItem, StoryPagingAdapter.ViewHolder>(DIFF_CALLBACK) {

    class ViewHolder(private val binding: ItemRowUserBinding) :
        RecyclerView.ViewHolder(binding.root) {


        fun bind(data: PagingStoryItem) {
            Glide.with(binding.root.context)
                .load(data.photoUrl)
                .circleCrop()
                .into(binding.imgPhoto)
            binding.tvName.text = data.name

            binding.root.setOnClickListener {
                val story = Storydata(
                    data.name,
                    data.photoUrl,
                    data.description,
                    null,
                    null
                )

                val optionsCompat: ActivityOptionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(
                    binding.root.context as Activity,
                    Pair(binding.imgPhoto, "img_photo_detail_transition"),
                    Pair(binding.tvName, "tv_name_detail_transition")
                )

                val intent = Intent(binding.root.context, StoryDetailActivity::class.java)
                intent.putExtra(StoryDetailActivity.DETAIL_STORY, story)
                binding.root.context.startActivity(intent, optionsCompat.toBundle())
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRowUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }



    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = getItem(position)
        if (data != null) {
            holder.bind(data)
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<PagingStoryItem>() {
            override fun areItemsTheSame(
                oldItem: PagingStoryItem,
                newItem: PagingStoryItem
            ): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: PagingStoryItem,
                newItem: PagingStoryItem
            ): Boolean {
                return oldItem.id == newItem.id
            }
        }
    }
}