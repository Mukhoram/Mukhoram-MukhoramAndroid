package com.dicoding.picodiploma.storysubmission

data class InputErrorHandling(
    val emailError: Int? = null,
    val passwordError: Int? = null
)
