package com.dicoding.picodiploma.storysubmission

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.dicoding.picodiploma.storysubmission.databinding.ActivityRegisterBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity() {
    private lateinit var activityRegisterBinding: ActivityRegisterBinding
    private lateinit var registerViewModel: RegisterViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityRegisterBinding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(activityRegisterBinding.root)

        registerViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        ).get(RegisterViewModel::class.java)

        setupView()
        playAnimation()

        activityRegisterBinding.nameEditText.type = "name"
        activityRegisterBinding.emailEditText.type = "email"
        activityRegisterBinding.passwordEditText.type = "password"

        activityRegisterBinding.signupButton.setOnClickListener {
            val inputName = activityRegisterBinding.nameEditText.text.toString()
            val inputEmail = activityRegisterBinding.emailEditText.text.toString()
            val inputPassword = activityRegisterBinding.passwordEditText.text.toString()

            createAccount(inputName, inputEmail, inputPassword)
        }
    }


//        val inputName = activityRegisterBinding.nameEditText
//        val inputEmail = activityRegisterBinding.emailEditText
//        val inputPassword = activityRegisterBinding.passwordEditText
//        val signupBtn = activityRegisterBinding.signupButton
//
//
//
//        registerViewModel.authState.observe(this@RegisterActivity, Observer {
//            val regisState = it ?: return@Observer
//
//            if (regisState.emailError != null) {
//                inputEmail.error = getString(regisState.emailError)
//            }
//            if (regisState.passwordError != null) {
//                inputPassword.error = getString(regisState.passwordError)
//            }
//        })

//        inputEmail.afterTextChanged {
//            registerViewModel.dataChecker(
//                inputEmail.text.toString(),
//                inputPassword.text.toString()
//            )
//        }
//
//        inputPassword.apply {
//            afterTextChanged {
//                registerViewModel.dataChecker(
//                    inputEmail.text.toString(),
//                    inputPassword.text.toString()
//                )
//            }
//
//
//            signupBtn.setOnClickListener {
//                createAccount(
//                    inputName.text.toString().trim(),
//                    inputEmail.text.toString().trim(),
//                    inputPassword.text.toString().trim()
//                )
//            }
//        }


    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun createAccount(inputName: String, inputEmail: String, inputPassword: String) {
        showLoading(true)

        val client = ApiConfig.getApiService().createAccount(inputName, inputEmail, inputPassword)
        client.enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
            ) {
                showLoading(false)
                val responseBody = response.body()
                Log.e(TAG, "onResponse: $responseBody")
                if (response.isSuccessful && responseBody?.message == "User created") {
                    Log.e(TAG, "isSuccessful: $responseBody")
                    Toast.makeText(
                        this@RegisterActivity,
                        getString(R.string.register_success),
                        Toast.LENGTH_SHORT
                    ).show()
                    val intent = Intent(this@RegisterActivity, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    Log.e(TAG, "isNotSuccessful: ${response.message()}")
                    Toast.makeText(
                        this@RegisterActivity,
                        getString(R.string.register_fail),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                showLoading(false)
                Log.e(TAG, "onFailure: ${t.message}")
                Toast.makeText(
                    this@RegisterActivity,
                    getString(R.string.register_fail),
                    Toast.LENGTH_SHORT
                ).show()
            }

        })
    }

//    private fun EditText.afterTextChanged(afterTextChanged: (String) -> Unit) {
//        this.addTextChangedListener(object : TextWatcher {
//            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
//
//            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
//
//            override fun afterTextChanged(editable: Editable?) {
//                afterTextChanged.invoke(editable.toString())
//            }
//        })
//    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            activityRegisterBinding.progressBar.visibility = View.VISIBLE
        } else {
            activityRegisterBinding.progressBar.visibility = View.GONE
        }
    }

    companion object {
        private const val TAG = "RegisterActivity"
    }


    private fun playAnimation() {
        ObjectAnimator.ofFloat(activityRegisterBinding.imageView, View.TRANSLATION_X, -60f, 60f)
            .apply {
                duration = 6000
                repeatCount = ObjectAnimator.INFINITE
                repeatMode = ObjectAnimator.REVERSE
            }.start()


        val nameTextView =
            ObjectAnimator.ofFloat(activityRegisterBinding.nameTextView, View.ALPHA, 1f)
                .setDuration(500)
//        val nameEditTextLayout =
//            ObjectAnimator.ofFloat(activityRegisterBinding.nameEditTextLayout, View.ALPHA, 1f)
//                .setDuration(500)
        val emailTextView =
            ObjectAnimator.ofFloat(activityRegisterBinding.emailTextView, View.ALPHA, 1f)
                .setDuration(500)
//        val emailEditTextLayout =
//            ObjectAnimator.ofFloat(activityRegisterBinding.emailEditTextLayout, View.ALPHA, 1f)
//                .setDuration(500)
        val passwordTextView =
            ObjectAnimator.ofFloat(activityRegisterBinding.passwordTextView, View.ALPHA, 1f)
                .setDuration(500)
//        val passwordEditTextLayout =
//            ObjectAnimator.ofFloat(activityRegisterBinding.passwordEditTextLayout, View.ALPHA, 1f)
//                .setDuration(500)
        val signup = ObjectAnimator.ofFloat(activityRegisterBinding.signupButton, View.ALPHA, 1f)
            .setDuration(500)

        AnimatorSet().apply {
            playSequentially(
                nameTextView,
//                nameEditTextLayout,
                emailTextView,
//                emailEditTextLayout,
                passwordTextView,
//                passwordEditTextLayout,
                signup
            )
            startDelay = 500
        }.start()
    }
}



