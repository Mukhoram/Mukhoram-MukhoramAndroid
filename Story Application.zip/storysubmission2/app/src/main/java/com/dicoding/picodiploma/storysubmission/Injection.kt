package com.dicoding.picodiploma.storysubmission

import android.content.Context

object Injection {
    fun provideRepository(context: Context): StoryRepository {
        val database = StoryDB.getDatabase(context)
        val apiService = ApiConfig.getApiService()

        return StoryRepository(database, apiService)
    }
}