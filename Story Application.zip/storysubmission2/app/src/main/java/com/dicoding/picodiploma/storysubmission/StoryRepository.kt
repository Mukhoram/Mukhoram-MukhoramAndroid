package com.dicoding.picodiploma.storysubmission

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.paging.*

class StoryRepository(private val storiesDatabase: StoryDB, private val apiService: ApiService) {
    fun getStoriesForPaging(header: String) : LiveData<PagingData<PagingStoryItem>> {
        return Pager(
            config = PagingConfig(
                pageSize = 5,
            ),
            pagingSourceFactory = {
                StoryPagingRes(apiService, header)
            }
        ).liveData
    }
    companion object{
        const val TAG = "StoryRepository"
    }

}