package com.dicoding.picodiploma.storysubmission

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase



    @Database(
        entities = [PagingStoryItem::class],
        version = 1,
        exportSchema = false
    )

    abstract class StoryDB : RoomDatabase() {

        companion object {
            @Volatile
            private var INSTANCE: StoryDB? = null

            @JvmStatic
            fun getDatabase(context: Context): StoryDB{
                return INSTANCE ?: synchronized(this) {
                    INSTANCE ?: Room.databaseBuilder(
                        context.applicationContext,
                        StoryDB::class.java, "stories_database"
                    ).fallbackToDestructiveMigration()
                        .build()
                        .also { INSTANCE = it }
                }
            }
        }
    }
