package com.dicoding.picodiploma.storysubmission

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Storydata(
    var name: String? = null,
    var photo: String? = null,
    var description: String? = null,
    var lat: Double? = null,
    var lon: Double? = null
) : Parcelable