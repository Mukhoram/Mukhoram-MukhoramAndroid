package com.dicoding.picodiploma.storysubmission

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.paging.map
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.storysubmission.databinding.ActivityStoryBinding


private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")



class StoryActivity : AppCompatActivity() {

    private lateinit var sharedViewModel: MainViewModel
    private val storyViewModel: StoryViewModel by viewModels {
        StoryViewModel.ViewModelFactory(this)
    }
    private lateinit var activityStoryBinding: ActivityStoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityStoryBinding = ActivityStoryBinding.inflate(layoutInflater)
        setContentView(activityStoryBinding.root)

        setupViewModel()

        val layoutManager = LinearLayoutManager(this)
        activityStoryBinding.rvStory.layoutManager = layoutManager

        getStories()
    }

    private fun setupViewModel() {
        sharedViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[MainViewModel::class.java]
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.add_story -> {
                val intent = Intent(this, StoryAddActivity::class.java)
                startActivity(intent)

            }
            R.id.menu_map -> {
                val mapIntent = Intent(this@StoryActivity, MapsActivity::class.java)
                startActivity(mapIntent)
            }

            R.id.menu1 -> {
                sharedViewModel.logout()
//                val intent = Intent(this, MainActivity::class.java)
//                startActivity(intent)
                finish()

            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun getStories() {
        val adapter = StoryPagingAdapter()
        activityStoryBinding.rvStory.adapter = adapter.withLoadStateFooter(
            footer = LoadingStateAdapter {
                adapter.retry()
            }
        )
        sharedViewModel.getUser().observe(this) { userAuth ->
            if(userAuth != null) {
                storyViewModel.stories("Bearer " + userAuth.token).observe(this) { stories ->
                    adapter.submitData(lifecycle, stories)
                    if(adapter.itemCount != null) {
                        Log.e(TAG, "Successfully fetched..." )
                    } else {
                        Log.e(TAG, "Unable to fetch data..." )
                    }
                }
            }
        }

    }
    companion object {
        const val TAG = "StoryActivity"
    }
}