package com.dicoding.picodiploma.storysubmission

import android.content.Context
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.dicoding.picodiploma.storysubmission.ApiService
import com.dicoding.picodiploma.storysubmission.ListStoryItem

class StoryPagingRes(private val apiService: ApiService, private val token: String) :
    PagingSource<Int, PagingStoryItem>() {

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, PagingStoryItem> {
        return try {
            Log.e("Token = ", "$token" )
            val position = params.key ?: INITIAL_PAGE
            val responseData =
                apiService.getStories(token.trim(), position, params.loadSize)

            LoadResult.Page(
                data = responseData.listStory,
                prevKey = if (position == INITIAL_PAGE) null else position - 1,
                nextKey = if (responseData.listStory.isNullOrEmpty()) null else position + 1
            )
        } catch (e: Exception) {
            return LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, PagingStoryItem>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            val anchorPage = state.closestPageToPosition(anchorPosition)
            anchorPage?.prevKey?.plus(1) ?: anchorPage?.nextKey?.minus(1)
        }
    }

    private companion object {
        const val INITIAL_PAGE = 1
    }
}