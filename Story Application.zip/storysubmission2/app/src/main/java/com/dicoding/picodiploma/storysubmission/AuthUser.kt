package com.dicoding.picodiploma.storysubmission

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class AuthUser(
    val token: String,
    val isLogin: Boolean
) : Parcelable