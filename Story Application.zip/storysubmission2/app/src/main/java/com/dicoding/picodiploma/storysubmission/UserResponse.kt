package com.dicoding.picodiploma.storysubmission

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class UserResponse(
    @SerializedName("loginResult")
    @Expose
    var loginResult: Users? = null,

    @SerializedName("error")
    @Expose
    val error: Boolean,

    @SerializedName("message")
    @Expose
    val message: String
)

data class Users(
    @SerializedName("email")
    @Expose
    var email: String? = null,

    @SerializedName("name")
    @Expose
    var name: String? = null,

    @SerializedName("token")
    var token: String? = null
)
