package com.dicoding.picodiploma.storysubmission

data class Userdata(
    val name: String,
    val email: String,
    val password: String,
    val isLogin: Boolean
)