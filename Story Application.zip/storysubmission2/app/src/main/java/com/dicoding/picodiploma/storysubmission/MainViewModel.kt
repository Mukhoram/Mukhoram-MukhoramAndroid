package com.dicoding.picodiploma.storysubmission

import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class MainViewModel(private val pref: UserPreference) : ViewModel() {

    fun getUser(): LiveData<AuthUser> {
        return pref.getUser().asLiveData()
    }

    fun saveUser(user: AuthUser) {
        viewModelScope.launch {
            pref.saveUser(user)
        }
    }

    fun logout() {
        viewModelScope.launch {
            pref.logout()
        }
    }
//    fun removeToken() {
//        val prefEditor: SharedPreferences.Editor = preference.edit()
//        prefEditor.clear()
//        prefEditor.apply()
//    }
//    companion object {
//        const val EMAIL = "email"
//        const val TOKEN = "token"
//    }

}