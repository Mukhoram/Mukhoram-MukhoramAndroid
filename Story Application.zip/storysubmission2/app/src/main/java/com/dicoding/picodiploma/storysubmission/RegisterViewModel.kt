package com.dicoding.picodiploma.storysubmission

import android.util.Patterns
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class RegisterViewModel : ViewModel() {
    private val _authState = MutableLiveData<InputErrorHandling>()
    val authState: LiveData<InputErrorHandling> = _authState

    fun dataChecker(email: String, password: String) {
        if (!isPasswordValid(password)) {
            _authState.value = InputErrorHandling(passwordError = R.string.password_warning)
        }
        if (!isEmailValid(email)) {
            _authState.value = InputErrorHandling(emailError = R.string.email_warning)
        }
    }

    private fun isEmailValid(email: String): Boolean {
        return if (email.contains('@')) {
            Patterns.EMAIL_ADDRESS.matcher(email).matches()
        } else {
            email.isNotBlank()
        }
    }

    private fun isPasswordValid(password: String): Boolean {
        return password.length > 5
    }
}