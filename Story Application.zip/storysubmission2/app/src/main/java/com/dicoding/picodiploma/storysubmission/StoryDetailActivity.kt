package com.dicoding.picodiploma.storysubmission

import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.storysubmission.databinding.ActivityStoryDetailBinding

class StoryDetailActivity : AppCompatActivity() {
    private lateinit var activityDetailStoryBinding: ActivityStoryDetailBinding



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityDetailStoryBinding = ActivityStoryDetailBinding.inflate(layoutInflater)
        setContentView(activityDetailStoryBinding.root)

        val story = intent.getParcelableExtra<Storydata>(DETAIL_STORY) as Storydata
        Glide.with(this)
            .load(story.photo)
            .into(activityDetailStoryBinding.imgPhotoDetail)
        activityDetailStoryBinding.tvNameDetail.text = story.name
        activityDetailStoryBinding.tvDescriptionDetail.text = story.description
    }

    companion object {
        const val DETAIL_STORY = "detail_story"
    }
}
