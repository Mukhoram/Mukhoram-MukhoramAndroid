package com.dicoding.picodiploma.storysubmission

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.dicoding.picodiploma.storysubmission.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MainActivity : AppCompatActivity() {
    private lateinit var mainViewModel: MainViewModel
    private lateinit var activityMainBinding: ActivityMainBinding

    companion object {
        private const val TAG = "Main Activity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(activityMainBinding.root)

        setupView()
        setupViewModel()
        playAnimation()

        activityMainBinding.loginButton.setOnClickListener {
            val inputEmail = activityMainBinding.emailEditText.text.toString()
            val inputPassword = activityMainBinding.passwordEditText.text.toString()

            login(inputEmail, inputPassword)
        }

        activityMainBinding.btnRegister.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }


    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setupViewModel() {
        mainViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[MainViewModel::class.java]

        mainViewModel.getUser().observe(this) { user ->
            if (user.isLogin) {
                val intent = Intent(this, StoryActivity::class.java)
                startActivity(intent)
            }
        }
    }


    private fun login(inputEmail: String, inputPassword: String) {
        showLoading(true)

        val client = ApiConfig.getApiService().login(inputEmail, inputPassword)
        client.enqueue(object : Callback<UserResponse> {
            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                showLoading(false)
                val responseBody = response.body()
                Log.d(TAG, "onResponse: $responseBody")
                if (response.isSuccessful && responseBody?.message == "success") {
                    mainViewModel.saveUser(AuthUser(responseBody.loginResult!!.token!!, true))
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.login_success),
                        Toast.LENGTH_SHORT
                    ).show()
                    val intent = Intent(this@MainActivity, StoryActivity::class.java)
                    startActivity(intent)
                   return finish()
                    
                } else {
                    Log.e(TAG, "onFailure1: ${response.message()}")
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.login_fail),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                showLoading(false)
                Log.e(TAG, "onFailure2: ${t.message}")
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.login_fail),
                    Toast.LENGTH_SHORT
                ).show()
            }

        })
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            activityMainBinding.progressBar.visibility = View.VISIBLE
        } else {
            activityMainBinding.progressBar.visibility = View.GONE
        }
    }

    private fun playAnimation() {

        ObjectAnimator.ofFloat(activityMainBinding.imageView, View.TRANSLATION_X, -60f, 60f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val emailTextView =
            ObjectAnimator.ofFloat(activityMainBinding.emailTextView, View.ALPHA, 1f)
                .setDuration(500)
//        val emailEditTextLayout =
//            ObjectAnimator.ofFloat(activityMainBinding.emailEditTextLayout, View.ALPHA, 1f)
//                .setDuration(500)
        val passwordTextView =
            ObjectAnimator.ofFloat(activityMainBinding.passwordTextView, View.ALPHA, 1f)
                .setDuration(500)
//        val passwordEditTextLayout =
//            ObjectAnimator.ofFloat(activityMainBinding.passwordEditTextLayout, View.ALPHA, 1f)
//                .setDuration(500)
        val login =
            ObjectAnimator.ofFloat(activityMainBinding.loginButton, View.ALPHA, 1f).setDuration(500)
        val question = ObjectAnimator.ofFloat(activityMainBinding.tvAccountQuestion, View.ALPHA, 1f)
            .setDuration(500)
        val reg =
            ObjectAnimator.ofFloat(activityMainBinding.btnRegister, View.ALPHA, 1f).setDuration(500)

        AnimatorSet().apply {
            playSequentially(
                emailTextView,
//                emailEditTextLayout,
                passwordTextView,
//                passwordEditTextLayout,
                login,
                question,
                reg
            )
            startDelay = 500
        }.start()
    }


}

