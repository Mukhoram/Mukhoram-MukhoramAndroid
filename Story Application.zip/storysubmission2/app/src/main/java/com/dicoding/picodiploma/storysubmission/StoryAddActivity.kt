package com.dicoding.picodiploma.storysubmission

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.dicoding.picodiploma.storysubmission.MapsActivity.Companion.LAT
import com.dicoding.picodiploma.storysubmission.MapsActivity.Companion.LON
import com.dicoding.picodiploma.storysubmission.databinding.ActivityStoryAddBinding
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class StoryAddActivity : AppCompatActivity() {
    private lateinit var addStoryViewModel: MainViewModel
    private lateinit var activityAddStoryBinding: ActivityStoryAddBinding
    private var getFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityAddStoryBinding = ActivityStoryAddBinding.inflate(layoutInflater)
        setContentView(activityAddStoryBinding.root)

        setupViewModel()
        playAnimation()

        val lat = intent.getFloatExtra(LAT.toString(), 1000f)
        val lon = intent.getFloatExtra(LON.toString(), 1000f)

        if(lat != 1000f && lon != 1000f) {
            val location = "Latitude = $lat, \nLongitude = $lon"
            activityAddStoryBinding.locateval.text = location
        }

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this,
                REQUIRED_PERMISSIONS,
                REQUEST_CODE_PERMISSIONS
            )
        }

        activityAddStoryBinding.cameraBtn.setOnClickListener {
            startCamera()
        }

        activityAddStoryBinding.galleryBtn.setOnClickListener {
            startGallery()
        }

        activityAddStoryBinding.uploadBtn.setOnClickListener {
            uploadImage(lat, lon)
        }
    }

    private fun setupViewModel() {
        addStoryViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[MainViewModel::class.java]
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)

        val addMenu = menu.findItem(R.id.add_story)
        addMenu.isVisible = false

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {


            R.id.menu1 -> {
                addStoryViewModel.logout()
//                val intent = Intent(this, MainActivity::class.java)
//                startActivity(intent)
                finish()

            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_LONG)
                    .show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCamera() {
        val intent = Intent(this, CameraActivity::class.java)
        launcherIntentCameraX.launch(intent)
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Choose a Picture")
        launcherIntentGallery.launch(chooser)
    }

    private fun uploadImage(lat: Float, lon: Float) {
        showLoading(true)

        if (getFile != null) {
            val file = reduceFileImage(getFile as File)

            val description = activityAddStoryBinding.DescriptionEditText.text.toString()
                .toRequestBody("text/plain".toMediaType())
            val requestImageFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
            val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
                "photo",
                file.name,
                requestImageFile
            )

            addStoryViewModel.getUser().observe(this) {
                if(it != null) {
                    val client = if(lat != 1000f && lon != 1000f) {
                        ApiConfig.getApiService().uploadStoriesWithLocation("Bearer " + it.token, imageMultipart, description, lat, lon)
                    } else {
                        ApiConfig.getApiService().uploadImage("Bearer " + it.token, imageMultipart, description)
                    }
                    client.enqueue(object : Callback<FileResponse> {
                        override fun onResponse(
                            call: Call<FileResponse>,
                            response: Response<FileResponse>
                        ) {
                            showLoading(false)
                            val responseBody = response.body()
                            Log.d(TAG, "onResponse: $responseBody")
                            if (response.isSuccessful && responseBody?.message == "Story created successfully") {
                                Toast.makeText(
                                    this@StoryAddActivity,
                                    getString(R.string.upload_success),
                                    Toast.LENGTH_SHORT
                                ).show()
                                val intent =
                                    Intent(this@StoryAddActivity, StoryActivity::class.java)
                                startActivity(intent)
                                finish()
                            } else {
                                Log.e(TAG, "onFailure1: ${response.message()}")
                                Toast.makeText(
                                    this@StoryAddActivity,
                                    getString(R.string.upload_fail),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        override fun onFailure(call: Call<FileResponse>, t: Throwable) {
                            showLoading(false)
                            Log.e(TAG, "onFailure2: ${t.message}")
                            Toast.makeText(
                                this@StoryAddActivity,
                                getString(R.string.upload_fail),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    })
                }
            }

        }

    }

    private val launcherIntentCameraX = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == CAMERA_X_RESULT) {
            val myFile = it.data?.getSerializableExtra("picture") as File
            val isBackCamera = it.data?.getBooleanExtra("isBackCamera", true) as Boolean
            getFile = myFile

            val result = rotateBitmap(
                BitmapFactory.decodeFile(myFile.path),
                isBackCamera
            )

            activityAddStoryBinding.imgPreview.setImageBitmap(result)
        }
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg: Uri = result.data?.data as Uri
            val myFile = uriToFile(selectedImg, this@StoryAddActivity)
            getFile = myFile
            activityAddStoryBinding.imgPreview.setImageURI(selectedImg)
        }
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            activityAddStoryBinding.progressBar.visibility = View.VISIBLE
        } else {
            activityAddStoryBinding.progressBar.visibility = View.GONE
        }
    }

    private fun playAnimation() {


//
        val Desc = ObjectAnimator.ofFloat(activityAddStoryBinding.DescriptionAdd, View.ALPHA, 1f)
            .setDuration(500)
        val DescEditTextLayout = ObjectAnimator.ofFloat(
            activityAddStoryBinding.DescriptionEditTextLayout,
            View.ALPHA,
            1f
        ).setDuration(500)


        AnimatorSet().apply {
            playSequentially(Desc, DescEditTextLayout)
            startDelay = 500
        }.start()
    }

    companion object {
        const val TAG = "AddStoryActivity"
        const val CAMERA_X_RESULT = 200

        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }
}